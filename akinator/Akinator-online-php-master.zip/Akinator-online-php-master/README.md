# Akinator-online-php
Versión online funcional de Akinator. Incluye 5 tipos de respuestas: sí, no, proablemente sí, probablemente no y no lo sé.
Para hacerlo funcionar sigue los siguientes pasos:
1- Cambia las variables de conexión a la BD del archivo "conexion.php".
2- Crea una base de datos en tu servidor MySQL llamada "javinator".
3- Abre la página "instalar.php" para crear las tablas correspondientes en la BD.
4- Si quieres reiniciar la base de datos, tienes el script "desinstalar.php" que borra las tablas y las reinicia.

Para entender el funcionamiento del software, visita mis vídeos de YouTube en mi canal "Programar es increible" https://www.youtube.com/channel/UCS9KSwTM3FO2Ovv83W98GTg

Vídeo 1: https://youtu.be/59kUKbydMeA
